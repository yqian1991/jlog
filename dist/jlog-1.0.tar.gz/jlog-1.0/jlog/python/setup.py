from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
import shutil, os

ext_modules=[
  Extension(
    "jlog",
    ["jlog.pyx"],
    libraries = ["jlog"],
    include_dirs = [
      "/usr/local/include",
      "/usr/include"],
    library_dirs = [
      "/usr/local/lib",
      "/usr/lib"]
  )
]

setup(
  name = "jlog",
  version = "1.0",
  description = "JLog Python Library",
  url = "https://labs.omniti.com/labs/jlog",
  ext_modules = cythonize(ext_modules)
)

PACKAGE_DATA = ['libjlog.so.2']

PATH='/opt/webapp/emailsvc/lib/'

#for package in PACKAGE_DATA:
#    shutil.copy2(package, PATH)

os.environ['LD_LIBRARY_PATH'] = PATH
